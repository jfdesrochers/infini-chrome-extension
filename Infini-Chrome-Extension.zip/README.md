google-calendar-daylight-extension
==================================

Chrome Extension that modifies Google Calendar to visualize daylight hours in your timezone.

You can install the extension from the Chrome web store at https://chrome.google.com/webstore/detail/daylight-for-google-calen/iekoigdlnhmafemfoamlnmhihmcfcklk?hl=en
